## Real-Time Search Results
URL: https://x.com/anyuser/status/1986428176877187348
- Text: So has every other resale platform you can think of. StockX’s hiccups were just the loudest. I’m not even caping for the company like that, but facts are facts. Respectfully, of course. https://t.co/IpQUTZAdJR

- Like Count: 22
- Retweet Count: 3

URL: https://x.com/anyuser/status/1986749218455945585
- Text: Selling a $200 sneaker on resale platforms:

StockX: $174 after fees
GOAT: $176 after fees
eBay: $165 after fees
Average: $171 after fees

METAZ? $194 after fees.

Keep MORE of your profit. https://t.co/JSS0YHZJVM

- Like Count: 4
- Retweet Count: 1

## End of Real-Time Search Results
